import React from 'react';

const Users = () => {
    return (
        <div>
            <h1>사용자</h1>
        </div>
    );
};

export default Users;